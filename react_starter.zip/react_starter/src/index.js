import React from 'react';
import ReactDOM from 'react-dom';
import { IntlProvider } from 'react-intl';
import { Provider } from 'react-redux';
import { ConnectedRouter } from 'connected-react-router';

import configureStore, { history } from './redux/configureStore';


import messages_es from './localization/es.json';
import messages_en from './localization/en.json';

import Routes from './routes';

const store = configureStore();

const messages = {
  es: messages_es,
  en: messages_en
};

const lang = navigator.language.split(/[-_]/)[0];

function App(props) {
  return (
    <Provider store={store}>
      <IntlProvider locale={lang} messages={messages[lang]}>
        <ConnectedRouter history={history}>
          <Routes {...props} />
        </ConnectedRouter>
      </IntlProvider>
    </Provider>
  );
}

ReactDOM.render(<App />, document.getElementById('root'));
