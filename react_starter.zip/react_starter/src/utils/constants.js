const Status = {
  INIT: 0,
  PENDING: 1,
  DONE: 2,
  FAIL: 3
};

// eslint-disable-next-line import/prefer-default-export
export { Status };
