import React from 'react';
import { FormattedMessage } from 'react-intl';

export const required = (value) =>
  typeof value !== 'number'
  && (!value || (value && typeof value !== 'object' && value.trim() === '')) && (
    <FormattedMessage id="REQUIRED" defaultMessage="Required" />
  );

export const onlyLetters = (value) =>
  value
  && !/^[A-Z]*$/i.test(value) && (
    <FormattedMessage
      id="ONLY_LETTERS_ARE_ALLOWED"
      defaultMessage="Only letters are allowed"
    />
  );
