import ErrorBoundary from './ErrorBoundary';

export default ErrorBoundary;
