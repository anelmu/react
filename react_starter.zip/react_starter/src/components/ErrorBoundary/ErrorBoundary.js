import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';

class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }

  componentDidCatch() {
    this.setState({ hasError: true });
  }

  render() {
    const { hasError } = this.state;
    const { children } = this.props;
    if (hasError) {
      return (
        <div data-spec="error-component">
          <FormattedMessage
            id="ERROR_HAS_OCCURED"
            defaultMessage="Error has ocurred"
          />
        </div>
      );
    }

    return children;
  }
}

const { object } = PropTypes;

ErrorBoundary.propTypes = {
  children: object
};

ErrorBoundary.defaultProps = {
  children: {}
};

export default ErrorBoundary;
