import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { FormattedMessage } from 'react-intl';
import { Field, reduxForm } from 'redux-form';

import Loader from '../Loader';
import InputField from '../../lib/InputField/InputField';
import { required, onlyLetters } from '../../utils/validators';

class Player extends Component {
  constructor(props) {
    super(props);

    this.state = {
      editable: false
    };
  }

  componentDidMount() {
    this.getPlayer();
  }

  componentDidUpdate(prevProps) {
    const { editPlayerSuccess } = this.props;
    if (editPlayerSuccess !== prevProps.editPlayerSuccess) {
      this.goBack();
    }
  }

  componentWillUnmount() {
    const { getPlayerInit } = this.props;
    getPlayerInit();
  }

  getPlayer = () => {
    const { getPlayer, match } = this.props;
    const { id } = match.params;
    getPlayer(id);
  };

  goBack = () => {
    const { goBack } = this.props;
    goBack();
  };

  editPlayer = () => {
    const { editable } = this.state;
    const { reset } = this.props;
    this.setState({
      editable: !editable
    });
    reset();
  };

  onSubmit = (values) => {
    const { editPlayer } = this.props;
    editPlayer(values.id, values);
  };

  render() {
    const {
      playerRequest,
      playerFail,
      player,
      handleSubmit,
      editPlayerRequest,
      pristine,
      invalid
    } = this.props;
    const { editable } = this.state;

    if (playerRequest || editPlayerRequest) return <Loader />;
    if (playerFail) return null;
    return (
      <div data-spec="player">
        <button
          type="button"
          onClick={() => this.goBack()}
          onKeyPress={() => this.goBack()}
        >
          <FormattedMessage id="BACK" defaultMessage="Back" />
        </button>
        {!editable && (
          <button
            type="button"
            onClick={() => this.editPlayer()}
            onKeyPress={() => this.editPlayer()}
          >
            <FormattedMessage id="EDIT" defaultMessage="Edit" />
          </button>
        )}
        {player && (
          <div>
            {!editable ? (
              <div>
                <div>{player.firstName}</div>
                <div>{player.lastName}</div>
                <div>{player.position}</div>
              </div>
            ) : (
              <form onSubmit={handleSubmit(this.onSubmit)}>
                <div>
                  <Field
                    name="firstName"
                    component={InputField}
                    type="text"
                    placeholder="First Name"
                    label="First Name"
                    validate={[required, onlyLetters]}
                  />

                  <Field
                    name="lastName"
                    component={InputField}
                    type="text"
                    placeholder="Last Name"
                    label="Last Name"
                    validate={[required]}
                  />
                </div>
                <button type="submit" disabled={pristine || invalid}>Save</button>
                <button
                  type="button"
                  onClick={() => this.editPlayer()}
                  onKeyPress={() => this.editPlayer()}
                >
                  <FormattedMessage id="CANCEL" defaultMessage="Cancel" />
                </button>
              </form>
            )}
          </div>
        )}
      </div>
    );
  }
}

const { func, bool, object } = PropTypes;

Player.propTypes = {
  getPlayer: func,
  getPlayerInit: func,
  editPlayerSuccess: object,
  reset: func,
  playerRequest: bool,
  playerFail: bool,
  player: object,
  match: object.isRequired,
  goBack: func.isRequired,
  handleSubmit: func.isRequired,
  editPlayer: func.isRequired,
  editPlayerRequest: bool,
  pristine: bool,
  invalid: bool
};

Player.defaultProps = {
  getPlayer: () => null,
  getPlayerInit: () => null,
  editPlayerSuccess: {},
  reset: () => null,
  playerRequest: false,
  playerFail: false,
  player: {},
  editPlayerRequest: false,
  pristine: false,
  invalid: false
};

export default reduxForm({
  form: 'player'
})(Player);
