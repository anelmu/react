import { connect } from 'react-redux';
import { push } from 'connected-react-router';

import Player from './Player';

import { getPlayer, editPlayer, getPlayerInit } from '../../redux/players/actions';
import {
  getPlayerRequest,
  getPlayerFail,
  getPlayerSuccess,
  editPlayerRequest,
  editPlayerFail,
  editPlayerSuccess
} from '../../redux/players/selectors';

const mapStateToProps = (state) => ({
  playerRequest: getPlayerRequest(state),
  playerFail: getPlayerFail(state),
  player: getPlayerSuccess(state),
  initialValues: getPlayerSuccess(state),
  editPlayerRequest: editPlayerRequest(state),
  editPlayerFail: editPlayerFail(state),
  editPlayerSuccess: editPlayerSuccess(state)
});

const mapDispatchToProps = (dispatch) => ({
  getPlayer: (id) => dispatch(getPlayer(id)),
  editPlayer: (id, data) => dispatch(editPlayer({ id, data })),
  getPlayerInit: () => dispatch(getPlayerInit()),
  goBack: () => dispatch(push('/'))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Player);
