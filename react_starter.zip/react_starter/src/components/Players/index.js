import { connect } from 'react-redux';
import { push } from 'connected-react-router';

import Players from './Players';

import { getPlayers } from '../../redux/players/actions';
import {
  getPlayersRequest,
  getPlayersFail,
  getPlayersSuccess
} from '../../redux/players/selectors';

const mapStateToProps = (state) => ({
  playersRequest: getPlayersRequest(state),
  playersFail: getPlayersFail(state),
  players: getPlayersSuccess(state)
});

const mapDispatchToProps = (dispatch) => ({
  getPlayers: () => dispatch(getPlayers()),
  goToPlayerOverview: (id) => dispatch(push(`/${id}`))
});

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(Players);
