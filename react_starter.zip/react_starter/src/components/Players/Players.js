import React, { Component } from 'react';
import PropTypes from 'prop-types';
import Loader from '../Loader';

import styles from './Players.scss';

class Players extends Component {
  componentDidMount() {
    this.getPlayers();
  }

  getPlayers = () => {
    const { getPlayers } = this.props;
    getPlayers();
  };

  goToPlayerOverview = (id) => {
    const { goToPlayerOverview } = this.props;
    goToPlayerOverview(id);
  };

  render() {
    const { playersRequest, playersFail, players } = this.props;

    if (playersRequest) return <Loader />;
    return (
      <div data-spec="players" className={styles.players}>
        {!playersRequest
          && !playersFail
          && players
          && players.length > 0
          && players.map((item) => (
            <div
              className={styles.player}
              onClick={() => this.goToPlayerOverview(item.id)}
              onKeyPress={() => this.goToPlayerOverview(item.id)}
              role="button"
              tabIndex={0}
              key={item.id}
            >
              {item.firstName}
            </div>
          ))}
      </div>
    );
  }
}

const { func, bool, array } = PropTypes;

Players.propTypes = {
  getPlayers: func,
  playersRequest: bool,
  playersFail: bool,
  players: array,
  goToPlayerOverview: func
};

Players.defaultProps = {
  getPlayers: () => null,
  playersRequest: false,
  playersFail: false,
  players: [],
  goToPlayerOverview: () => null
};

export default Players;
