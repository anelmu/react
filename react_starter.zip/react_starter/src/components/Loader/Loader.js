import React from 'react';
import loader from '../../assets/images/loader.gif';
import styles from './Loader.scss';

function Loader() {
  return (
    <div className={styles.loader} data-spec="loader">
      <img src={loader} alt="loader" />
    </div>
  );
}

export default Loader;
