import React from 'react';
import { FormattedMessage } from 'react-intl';

function PageNotFound() {
  return (
    <div data-spec="page-not-found">
      <FormattedMessage id="PAGE_NOT_FOUND" defaultMessage="Page not found" />
    </div>
  );
}

export default PageNotFound;
