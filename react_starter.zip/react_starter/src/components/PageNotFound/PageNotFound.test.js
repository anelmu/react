import React from 'react';
import { shallow } from 'enzyme';
import toJson from 'enzyme-to-json';
import '../../test/testSetup';

import PageNotFound from './PageNotFound';

const componentSetup = () => shallow(<PageNotFound />);

describe('<PageNotFound />', () => {
  let wrapper;

  beforeEach(() => {
    wrapper = componentSetup();
  });

  test('component should render itself without error and match snapshot', () => {
    expect(wrapper).toBeDefined();
    expect(toJson(wrapper)).toMatchSnapshot();
  });

  test('component should render elements', () => {
    expect(wrapper.find('[data-spec="page-not-found"]').exists()).toBe(true);
  });
});
