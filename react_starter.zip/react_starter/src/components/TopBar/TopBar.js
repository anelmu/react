import React from 'react';

import styles from './TopBar.scss';

function TopBar() {
  return (
    <div data-spec="top-bar" className={styles.top_bar}>
      Top Bar
    </div>
  );
}

export default TopBar;
