import React from 'react';
import { FormattedMessage } from 'react-intl';

function Footer() {
  return (
    <div data-spec="footer">
      <FormattedMessage id="COPYRIGHT" defaultMessage="Copyright" />
    </div>
  );
}


export default Footer;
