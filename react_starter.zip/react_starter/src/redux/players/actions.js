import globalAction, { actionInit } from '../global/globalAction';

import {
  getPlayers as getPlayersService,
  getPlayer as getPlayerService,
  editPlayer as editPlayerService
} from '../../services/PlayersService';

import { GET_PLAYERS, GET_PLAYER, EDIT_PLAYER } from './constants';

export const getPlayers = () => globalAction(GET_PLAYERS, getPlayersService);
export const getPlayersInit = () => actionInit(GET_PLAYERS);

export const getPlayer = (id) => globalAction(GET_PLAYER, getPlayerService, id);
export const getPlayerInit = () => actionInit(GET_PLAYER);

export const editPlayer = (params) =>
  globalAction(EDIT_PLAYER, editPlayerService, params);
