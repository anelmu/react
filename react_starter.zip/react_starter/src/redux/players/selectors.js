import { Status } from '../../utils/constants';

export const getPlayersRequest = (state) =>
  state.players.getPlayers.status === Status.PENDING;
export const getPlayersFail = (state) =>
  state.players.getPlayers.status === Status.FAIL;
export const getPlayersSuccess = (state) => state.players.getPlayers.data;

export const getPlayerRequest = (state) =>
  state.players.getPlayer.status === Status.PENDING;
export const getPlayerFail = (state) =>
  state.players.getPlayer.status === Status.FAIL;
export const getPlayerSuccess = (state) => state.players.getPlayer.data;

export const editPlayerRequest = (state) =>
  state.players.editPlayer.status === Status.PENDING;
export const editPlayerFail = (state) =>
  state.players.editPlayer.status === Status.FAIL;
export const editPlayerSuccess = (state) => state.players.editPlayer.data;
