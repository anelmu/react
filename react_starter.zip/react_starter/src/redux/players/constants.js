export const GET_PLAYERS = 'GET_PLAYERS';
export const GET_PLAYER = 'GET_PLAYER';
export const EDIT_PLAYER = 'EDIT_PLAYER';
