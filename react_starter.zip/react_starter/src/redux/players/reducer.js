import { combineReducers } from 'redux';
import globalReducer from '../global/globalReducer';

import {
  GET_PLAYERS,
  GET_PLAYER,
  EDIT_PLAYER
} from './constants';

export default combineReducers({
  getPlayers: globalReducer(GET_PLAYERS),
  getPlayer: globalReducer(GET_PLAYER),
  editPlayer: globalReducer(EDIT_PLAYER)
});
