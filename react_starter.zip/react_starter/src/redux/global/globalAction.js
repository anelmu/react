import { createAction } from 'redux-actions';

const request = (prefix) => createAction(`${prefix}_REQUEST`);
const success = (prefix) => createAction(`${prefix}_SUCCESS`);
const fail = (prefix) => createAction(`${prefix}_FAIL`);
const init = (prefix) => createAction(`${prefix}_INIT`);

const globalAction = (prefix, service, params, actions) => async (dispatch) => {
  try {
    dispatch(request(prefix)());
    const data = await service(params);
    dispatch(success(prefix)(data));
    if (actions && actions.init) {
      dispatch(init(prefix)());
    }
  } catch (error) {
    dispatch(fail(prefix)(error));
    if (actions && actions.init) {
      dispatch(init(prefix)());
    }
  }
};

export const actionInit = (prefix) => async (dispatch) => {
  dispatch(init(prefix)());
};

export default globalAction;
