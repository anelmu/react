import * as ApiService from './ApiService';

export const getPlayers = () =>
  ApiService.get('http://5bfc3529cf9d29001345c583.mockapi.io/players');

export const getPlayer = (id) =>
  ApiService.get(`http://5bfc3529cf9d29001345c583.mockapi.io/players/${id}`);

export const editPlayer = (params) =>
  ApiService.put(
    `http://5bfc3529cf9d29001345c583.mockapi.io/players/${params.id}`,
    params.data
  );
