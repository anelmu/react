import React from 'react';
import { Route, Switch, Redirect } from 'react-router-dom';

import MainLayout from '../layouts/MainLayout';
import PageNotFound from '../components/PageNotFound';
import ErrorBoundary from '../components/ErrorBoundary';
import Players from '../components/Players';
import Player from '../components/Player';

const routes = [
  {
    path: '/',
    exact: true,
    Component: Players,
    Layout: MainLayout
  },
  {
    path: '/:id',
    exact: true,
    Component: Player,
    Layout: MainLayout
  }
];

const Routes = (routeProps) => (
  <ErrorBoundary>
    <Switch>
      {routes.map(({ path, Layout, Component, exact }) => (
        <Route
          key={path}
          exact={exact}
          path={path}
          render={(props) =>
            (Layout ? (
              <Layout {...props} {...routeProps}>
                <Component {...props} {...routeProps} />
              </Layout>
            ) : (
              <Component {...props} />
            ))}
        />
      ))}
      {<Redirect from="*" to="/page-not-found" component={PageNotFound} />}
    </Switch>
  </ErrorBoundary>
);

export default Routes;
