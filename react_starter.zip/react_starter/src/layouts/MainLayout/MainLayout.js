import React from 'react';
import PropTypes from 'prop-types';

import TopBar from '../../components/TopBar';
import Footer from '../../components/Footer';

import styles from './MainLayout.scss';

function MainLayout(props) {
  const { children } = props;
  return (
    <div data-spec="main-layout">
      <TopBar />
      <main className={styles.main_wrapper}>{children}</main>
      <Footer />
    </div>
  );
}

const { object } = PropTypes;

MainLayout.propTypes = {
  children: object
};

MainLayout.defaultProps = {
  children: {}
};

export default MainLayout;
